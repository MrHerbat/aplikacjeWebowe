using System;

namespace cw10_layout.Models;

public class MyStudent
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Age { get; set; }
}
